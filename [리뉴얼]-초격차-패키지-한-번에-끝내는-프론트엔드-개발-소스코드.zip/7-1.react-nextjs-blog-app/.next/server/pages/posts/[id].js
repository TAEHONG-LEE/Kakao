"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/posts/[id]";
exports.ids = ["pages/posts/[id]"];
exports.modules = {

/***/ "./lib/posts.ts":
/*!**********************!*\
  !*** ./lib/posts.ts ***!
  \**********************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"getAllPostIds\": () => (/* binding */ getAllPostIds),\n/* harmony export */   \"getPostData\": () => (/* binding */ getPostData),\n/* harmony export */   \"getSortedPostsData\": () => (/* binding */ getSortedPostsData)\n/* harmony export */ });\n/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! path */ \"path\");\n/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! fs */ \"fs\");\n/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var gray_matter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! gray-matter */ \"gray-matter\");\n/* harmony import */ var gray_matter__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(gray_matter__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var remark__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! remark */ \"remark\");\n/* harmony import */ var remark_html__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! remark-html */ \"remark-html\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([remark__WEBPACK_IMPORTED_MODULE_3__, remark_html__WEBPACK_IMPORTED_MODULE_4__]);\n([remark__WEBPACK_IMPORTED_MODULE_3__, remark_html__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\nconst postsDirectory = path__WEBPACK_IMPORTED_MODULE_0___default().join(process.cwd(), \"posts\");\nfunction getSortedPostsData() {\n    // 파일 이름을 가져오기   /posts\n    const fileNames = fs__WEBPACK_IMPORTED_MODULE_1___default().readdirSync(postsDirectory);\n    // ['pre-rendering.md', 'ssg-ssr.md]\n    const allPostsData = fileNames.map((fileName)=>{\n        const id = fileName.replace(/\\.md$/, \"\");\n        // pre-rendering, ssg-ssr\n        // read markdown file as string\n        const fullPath = path__WEBPACK_IMPORTED_MODULE_0___default().join(postsDirectory, fileName);\n        const fileContents = fs__WEBPACK_IMPORTED_MODULE_1___default().readFileSync(fullPath, \"utf8\");\n        console.log(\"fileContents\", fileContents);\n        const matterResults = gray_matter__WEBPACK_IMPORTED_MODULE_2___default()(fileContents);\n        return {\n            id,\n            ...matterResults.data\n        };\n    });\n    return allPostsData.sort((a, b)=>{\n        if (a.date < b.date) {\n            return 1;\n        } else {\n            return -1;\n        }\n    });\n}\nfunction getAllPostIds() {\n    const fileNames = fs__WEBPACK_IMPORTED_MODULE_1___default().readdirSync(postsDirectory);\n    return fileNames.map((fileName)=>{\n        return {\n            params: {\n                id: fileName.replace(/\\.md$/, \"\")\n            }\n        };\n    });\n}\nasync function getPostData(id) {\n    const fullPath = path__WEBPACK_IMPORTED_MODULE_0___default().join(postsDirectory, `${id}.md`);\n    const fileContents = fs__WEBPACK_IMPORTED_MODULE_1___default().readFileSync(fullPath, \"utf8\");\n    const matterResult = gray_matter__WEBPACK_IMPORTED_MODULE_2___default()(fileContents);\n    const processedContent = await (0,remark__WEBPACK_IMPORTED_MODULE_3__.remark)().use(remark_html__WEBPACK_IMPORTED_MODULE_4__[\"default\"]).process(matterResult.content);\n    const contentHtml = processedContent.toString();\n    return {\n        id,\n        contentHtml,\n        ...matterResult.data\n    };\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9saWIvcG9zdHMudHMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBd0I7QUFDSjtBQUNhO0FBQ0Q7QUFDRDtBQUMvQixNQUFNSyxpQkFBaUJMLGdEQUFTLENBQUNPLFFBQVFDLEdBQUcsSUFBSTtBQUV6QyxTQUFTQyxxQkFBcUI7SUFFakMsdUJBQXVCO0lBQ3ZCLE1BQU1DLFlBQVlULHFEQUFjLENBQUNJO0lBQ2pDLG9DQUFvQztJQUVwQyxNQUFNTyxlQUFlRixVQUFVRyxHQUFHLENBQUNDLENBQUFBLFdBQVk7UUFFM0MsTUFBTUMsS0FBS0QsU0FBU0UsT0FBTyxDQUFDLFNBQVM7UUFDckMseUJBQXlCO1FBRXpCLCtCQUErQjtRQUMvQixNQUFNQyxXQUFXakIsZ0RBQVMsQ0FBQ0ssZ0JBQWdCUztRQUMzQyxNQUFNSSxlQUFlakIsc0RBQWUsQ0FBQ2dCLFVBQVU7UUFDL0NHLFFBQVFDLEdBQUcsQ0FBQyxnQkFBZ0JIO1FBRTVCLE1BQU1JLGdCQUFnQnBCLGtEQUFNQSxDQUFDZ0I7UUFFN0IsT0FBTztZQUNISDtZQUNBLEdBQUlPLGNBQWNDLElBQUk7UUFDMUI7SUFDSjtJQUVBLE9BQU9YLGFBQWFZLElBQUksQ0FBQyxDQUFDQyxHQUFHQyxJQUFNO1FBQy9CLElBQUlELEVBQUVFLElBQUksR0FBR0QsRUFBRUMsSUFBSSxFQUFFO1lBQ2pCLE9BQU87UUFDWCxPQUFPO1lBQ0gsT0FBTyxDQUFDO1FBQ1osQ0FBQztJQUNMO0FBQ0osQ0FBQztBQUdNLFNBQVNDLGdCQUFnQjtJQUM1QixNQUFNbEIsWUFBWVQscURBQWMsQ0FBQ0k7SUFDakMsT0FBT0ssVUFBVUcsR0FBRyxDQUFDQyxDQUFBQSxXQUFZO1FBQzdCLE9BQU87WUFDSGUsUUFBUTtnQkFDSmQsSUFBSUQsU0FBU0UsT0FBTyxDQUFDLFNBQVM7WUFDbEM7UUFDSjtJQUNKO0FBQ0osQ0FBQztBQUVNLGVBQWVjLFlBQVlmLEVBQVUsRUFBRTtJQUMxQyxNQUFNRSxXQUFXakIsZ0RBQVMsQ0FBQ0ssZ0JBQWdCLENBQUMsRUFBRVUsR0FBRyxHQUFHLENBQUM7SUFDckQsTUFBTUcsZUFBZWpCLHNEQUFlLENBQUNnQixVQUFVO0lBRS9DLE1BQU1jLGVBQWU3QixrREFBTUEsQ0FBQ2dCO0lBRTVCLE1BQU1jLG1CQUFtQixNQUFNN0IsOENBQU1BLEdBQ2hDOEIsR0FBRyxDQUFDN0IsbURBQUlBLEVBQ1JHLE9BQU8sQ0FBQ3dCLGFBQWFHLE9BQU87SUFFakMsTUFBTUMsY0FBY0gsaUJBQWlCSSxRQUFRO0lBRTdDLE9BQU87UUFDSHJCO1FBQ0FvQjtRQUNBLEdBQUlKLGFBQWFSLElBQUk7SUFDekI7QUFDSixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcmVhY3QtbmV4dGpzLWJhc2ljLWFwcC8uL2xpYi9wb3N0cy50cz85OTQ1Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBwYXRoIGZyb20gXCJwYXRoXCI7XG5pbXBvcnQgZnMgZnJvbSBcImZzXCI7XG5pbXBvcnQgbWF0dGVyIGZyb20gXCJncmF5LW1hdHRlclwiO1xuaW1wb3J0IHsgcmVtYXJrIH0gZnJvbSBcInJlbWFya1wiO1xuaW1wb3J0IGh0bWwgZnJvbSAncmVtYXJrLWh0bWwnO1xuY29uc3QgcG9zdHNEaXJlY3RvcnkgPSBwYXRoLmpvaW4ocHJvY2Vzcy5jd2QoKSwgJ3Bvc3RzJyk7XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRTb3J0ZWRQb3N0c0RhdGEoKSB7XG5cbiAgICAvLyDtjIzsnbwg7J2066aE7J2EIOqwgOyguOyYpOq4sCAgIC9wb3N0c1xuICAgIGNvbnN0IGZpbGVOYW1lcyA9IGZzLnJlYWRkaXJTeW5jKHBvc3RzRGlyZWN0b3J5KTtcbiAgICAvLyBbJ3ByZS1yZW5kZXJpbmcubWQnLCAnc3NnLXNzci5tZF1cblxuICAgIGNvbnN0IGFsbFBvc3RzRGF0YSA9IGZpbGVOYW1lcy5tYXAoZmlsZU5hbWUgPT4ge1xuXG4gICAgICAgIGNvbnN0IGlkID0gZmlsZU5hbWUucmVwbGFjZSgvXFwubWQkLywgJycpO1xuICAgICAgICAvLyBwcmUtcmVuZGVyaW5nLCBzc2ctc3NyXG5cbiAgICAgICAgLy8gcmVhZCBtYXJrZG93biBmaWxlIGFzIHN0cmluZ1xuICAgICAgICBjb25zdCBmdWxsUGF0aCA9IHBhdGguam9pbihwb3N0c0RpcmVjdG9yeSwgZmlsZU5hbWUpO1xuICAgICAgICBjb25zdCBmaWxlQ29udGVudHMgPSBmcy5yZWFkRmlsZVN5bmMoZnVsbFBhdGgsICd1dGY4Jyk7XG4gICAgICAgIGNvbnNvbGUubG9nKCdmaWxlQ29udGVudHMnLCBmaWxlQ29udGVudHMpO1xuXG4gICAgICAgIGNvbnN0IG1hdHRlclJlc3VsdHMgPSBtYXR0ZXIoZmlsZUNvbnRlbnRzKTtcblxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgaWQsXG4gICAgICAgICAgICAuLi4obWF0dGVyUmVzdWx0cy5kYXRhIGFzIHsgZGF0ZTogc3RyaW5nOyB0aXRsZTogc3RyaW5nOyB9KVxuICAgICAgICB9XG4gICAgfSlcblxuICAgIHJldHVybiBhbGxQb3N0c0RhdGEuc29ydCgoYSwgYikgPT4ge1xuICAgICAgICBpZiAoYS5kYXRlIDwgYi5kYXRlKSB7XG4gICAgICAgICAgICByZXR1cm4gMVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIC0xXG4gICAgICAgIH1cbiAgICB9KVxufVxuXG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRBbGxQb3N0SWRzKCkge1xuICAgIGNvbnN0IGZpbGVOYW1lcyA9IGZzLnJlYWRkaXJTeW5jKHBvc3RzRGlyZWN0b3J5KVxuICAgIHJldHVybiBmaWxlTmFtZXMubWFwKGZpbGVOYW1lID0+IHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgIGlkOiBmaWxlTmFtZS5yZXBsYWNlKC9cXC5tZCQvLCAnJylcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0pXG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRQb3N0RGF0YShpZDogc3RyaW5nKSB7XG4gICAgY29uc3QgZnVsbFBhdGggPSBwYXRoLmpvaW4ocG9zdHNEaXJlY3RvcnksIGAke2lkfS5tZGApO1xuICAgIGNvbnN0IGZpbGVDb250ZW50cyA9IGZzLnJlYWRGaWxlU3luYyhmdWxsUGF0aCwgJ3V0ZjgnKTtcblxuICAgIGNvbnN0IG1hdHRlclJlc3VsdCA9IG1hdHRlcihmaWxlQ29udGVudHMpO1xuXG4gICAgY29uc3QgcHJvY2Vzc2VkQ29udGVudCA9IGF3YWl0IHJlbWFyaygpXG4gICAgICAgIC51c2UoaHRtbClcbiAgICAgICAgLnByb2Nlc3MobWF0dGVyUmVzdWx0LmNvbnRlbnQpO1xuXG4gICAgY29uc3QgY29udGVudEh0bWwgPSBwcm9jZXNzZWRDb250ZW50LnRvU3RyaW5nKCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgICBpZCxcbiAgICAgICAgY29udGVudEh0bWwsXG4gICAgICAgIC4uLihtYXR0ZXJSZXN1bHQuZGF0YSBhcyB7IGRhdGU6IHN0cmluZzsgdGl0bGU6IHN0cmluZzsgfSlcbiAgICB9XG59Il0sIm5hbWVzIjpbInBhdGgiLCJmcyIsIm1hdHRlciIsInJlbWFyayIsImh0bWwiLCJwb3N0c0RpcmVjdG9yeSIsImpvaW4iLCJwcm9jZXNzIiwiY3dkIiwiZ2V0U29ydGVkUG9zdHNEYXRhIiwiZmlsZU5hbWVzIiwicmVhZGRpclN5bmMiLCJhbGxQb3N0c0RhdGEiLCJtYXAiLCJmaWxlTmFtZSIsImlkIiwicmVwbGFjZSIsImZ1bGxQYXRoIiwiZmlsZUNvbnRlbnRzIiwicmVhZEZpbGVTeW5jIiwiY29uc29sZSIsImxvZyIsIm1hdHRlclJlc3VsdHMiLCJkYXRhIiwic29ydCIsImEiLCJiIiwiZGF0ZSIsImdldEFsbFBvc3RJZHMiLCJwYXJhbXMiLCJnZXRQb3N0RGF0YSIsIm1hdHRlclJlc3VsdCIsInByb2Nlc3NlZENvbnRlbnQiLCJ1c2UiLCJjb250ZW50IiwiY29udGVudEh0bWwiLCJ0b1N0cmluZyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./lib/posts.ts\n");

/***/ }),

/***/ "./pages/posts/[id].tsx":
/*!******************************!*\
  !*** ./pages/posts/[id].tsx ***!
  \******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   \"getStaticPaths\": () => (/* binding */ getStaticPaths),\n/* harmony export */   \"getStaticProps\": () => (/* binding */ getStaticProps)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _lib_posts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/lib/posts */ \"./lib/posts.ts\");\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ \"next/head\");\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_posts__WEBPACK_IMPORTED_MODULE_1__]);\n_lib_posts__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\nconst Post = ({ postData  })=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"title\", {\n                    children: postData.title\n                }, void 0, false, {\n                    fileName: \"/Users/johnahn/Desktop/react-nextjs-basic-app/pages/posts/[id].tsx\",\n                    lineNumber: 16,\n                    columnNumber: 17\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"/Users/johnahn/Desktop/react-nextjs-basic-app/pages/posts/[id].tsx\",\n                lineNumber: 15,\n                columnNumber: 13\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"article\", {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                        children: postData.title\n                    }, void 0, false, {\n                        fileName: \"/Users/johnahn/Desktop/react-nextjs-basic-app/pages/posts/[id].tsx\",\n                        lineNumber: 19,\n                        columnNumber: 17\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        children: postData.date\n                    }, void 0, false, {\n                        fileName: \"/Users/johnahn/Desktop/react-nextjs-basic-app/pages/posts/[id].tsx\",\n                        lineNumber: 20,\n                        columnNumber: 17\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        dangerouslySetInnerHTML: {\n                            __html: postData.contentHtml\n                        }\n                    }, void 0, false, {\n                        fileName: \"/Users/johnahn/Desktop/react-nextjs-basic-app/pages/posts/[id].tsx\",\n                        lineNumber: 23,\n                        columnNumber: 17\n                    }, undefined)\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/johnahn/Desktop/react-nextjs-basic-app/pages/posts/[id].tsx\",\n                lineNumber: 18,\n                columnNumber: 13\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/johnahn/Desktop/react-nextjs-basic-app/pages/posts/[id].tsx\",\n        lineNumber: 14,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Post);\nconst getStaticPaths = async ()=>{\n    const paths = (0,_lib_posts__WEBPACK_IMPORTED_MODULE_1__.getAllPostIds)();\n    return {\n        paths,\n        fallback: false\n    };\n};\nconst getStaticProps = async ({ params  })=>{\n    const postData = await (0,_lib_posts__WEBPACK_IMPORTED_MODULE_1__.getPostData)(params?.id);\n    return {\n        props: {\n            postData\n        }\n    };\n};\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9wb3N0cy9baWRdLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUF3RDtBQUU1QjtBQUNIO0FBRXpCLE1BQU1JLE9BQU8sQ0FBQyxFQUFFQyxTQUFRLEVBTXZCLEdBQUs7SUFDRixxQkFDSSw4REFBQ0M7OzBCQUNHLDhEQUFDSixrREFBSUE7MEJBQ0QsNEVBQUNLOzhCQUFPRixTQUFTRSxLQUFLOzs7Ozs7Ozs7OzswQkFFMUIsOERBQUNDOztrQ0FDRyw4REFBQ0M7a0NBQUlKLFNBQVNFLEtBQUs7Ozs7OztrQ0FDbkIsOERBQUNEO2tDQUNJRCxTQUFTSyxJQUFJOzs7Ozs7a0NBRWxCLDhEQUFDSjt3QkFBSUsseUJBQXlCOzRCQUFFQyxRQUFRUCxTQUFTUSxXQUFXO3dCQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJN0U7QUFFQSxpRUFBZVQsSUFBSUEsRUFBQTtBQUVaLE1BQU1VLGlCQUFpQyxVQUFZO0lBQ3RELE1BQU1DLFFBQVFmLHlEQUFhQTtJQUUzQixPQUFPO1FBQ0hlO1FBQ0FDLFVBQVUsS0FBSztJQUNuQjtBQUNKLEVBQUM7QUFFTSxNQUFNQyxpQkFBaUMsT0FBTyxFQUFFQyxPQUFNLEVBQUUsR0FBSztJQUVoRSxNQUFNYixXQUFXLE1BQU1KLHVEQUFXQSxDQUFDaUIsUUFBUUM7SUFDM0MsT0FBTztRQUNIQyxPQUFPO1lBQ0hmO1FBQ0o7SUFDSjtBQUNKLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9yZWFjdC1uZXh0anMtYmFzaWMtYXBwLy4vcGFnZXMvcG9zdHMvW2lkXS50c3g/MjFlMCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBnZXRBbGxQb3N0SWRzLCBnZXRQb3N0RGF0YSB9IGZyb20gJ0AvbGliL3Bvc3RzJ1xuaW1wb3J0IHsgR2V0U3RhdGljUGF0aHMsIEdldFN0YXRpY1Byb3BzIH0gZnJvbSAnbmV4dCdcbmltcG9ydCBIZWFkIGZyb20gJ25leHQvaGVhZCdcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcblxuY29uc3QgUG9zdCA9ICh7IHBvc3REYXRhIH06IHtcbiAgICBwb3N0RGF0YToge1xuICAgICAgICB0aXRsZTogc3RyaW5nLFxuICAgICAgICBkYXRlOiBzdHJpbmcsXG4gICAgICAgIGNvbnRlbnRIdG1sOiBzdHJpbmdcbiAgICB9XG59KSA9PiB7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxIZWFkPlxuICAgICAgICAgICAgICAgIDx0aXRsZT57cG9zdERhdGEudGl0bGV9PC90aXRsZT5cbiAgICAgICAgICAgIDwvSGVhZD5cbiAgICAgICAgICAgIDxhcnRpY2xlPlxuICAgICAgICAgICAgICAgIDxoMT57cG9zdERhdGEudGl0bGV9PC9oMT5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICB7cG9zdERhdGEuZGF0ZX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MPXt7IF9faHRtbDogcG9zdERhdGEuY29udGVudEh0bWwgfX0gLz5cbiAgICAgICAgICAgIDwvYXJ0aWNsZT5cbiAgICAgICAgPC9kaXY+XG4gICAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBQb3N0XG5cbmV4cG9ydCBjb25zdCBnZXRTdGF0aWNQYXRoczogR2V0U3RhdGljUGF0aHMgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgcGF0aHMgPSBnZXRBbGxQb3N0SWRzKCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgICBwYXRocyxcbiAgICAgICAgZmFsbGJhY2s6IGZhbHNlXG4gICAgfVxufVxuXG5leHBvcnQgY29uc3QgZ2V0U3RhdGljUHJvcHM6IEdldFN0YXRpY1Byb3BzID0gYXN5bmMgKHsgcGFyYW1zIH0pID0+IHtcblxuICAgIGNvbnN0IHBvc3REYXRhID0gYXdhaXQgZ2V0UG9zdERhdGEocGFyYW1zPy5pZCBhcyBzdHJpbmcpO1xuICAgIHJldHVybiB7XG4gICAgICAgIHByb3BzOiB7XG4gICAgICAgICAgICBwb3N0RGF0YVxuICAgICAgICB9XG4gICAgfVxufSJdLCJuYW1lcyI6WyJnZXRBbGxQb3N0SWRzIiwiZ2V0UG9zdERhdGEiLCJIZWFkIiwiUmVhY3QiLCJQb3N0IiwicG9zdERhdGEiLCJkaXYiLCJ0aXRsZSIsImFydGljbGUiLCJoMSIsImRhdGUiLCJkYW5nZXJvdXNseVNldElubmVySFRNTCIsIl9faHRtbCIsImNvbnRlbnRIdG1sIiwiZ2V0U3RhdGljUGF0aHMiLCJwYXRocyIsImZhbGxiYWNrIiwiZ2V0U3RhdGljUHJvcHMiLCJwYXJhbXMiLCJpZCIsInByb3BzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/posts/[id].tsx\n");

/***/ }),

/***/ "gray-matter":
/*!******************************!*\
  !*** external "gray-matter" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("gray-matter");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "remark":
/*!*************************!*\
  !*** external "remark" ***!
  \*************************/
/***/ ((module) => {

module.exports = import("remark");;

/***/ }),

/***/ "remark-html":
/*!******************************!*\
  !*** external "remark-html" ***!
  \******************************/
/***/ ((module) => {

module.exports = import("remark-html");;

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("path");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/posts/[id].tsx"));
module.exports = __webpack_exports__;

})();