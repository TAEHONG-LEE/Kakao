import React, { useEffect, useState } from 'react';
import logo from './logo.svg';
import './App.css';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from './reducers';
import { ActionType } from './reducers/posts';
import axios from 'axios';
import { fetchPosts } from './actions/posts';

type Props = {
  onIncrement: () => void;
  onDecrement: () => void;
}

function App({ onIncrement, onDecrement }: Props) {
  const [todoValue, setTodoValue] = useState("");
  const counter = useSelector((state: RootState) => state.counter);
  const todos: string[] = useSelector((state: RootState) => state.todos);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchPosts());
  }, [])

  // async function fetchPosts() {
  //   const response = await axios.get("https://jsonplaceholder.typicode.com/posts");
  //   dispatch({ type: ActionType.FETCH_POSTS, payload: response.data });
  // };

  // const fetchPosts: any = () => {
  //   return async function fetchPostsThunk(dispatch: any, getState: any) {
  //     if (getState().counter > 5) return;
  //     const response = await axios.get("https://jsonplaceholder.typicode.com/posts");
  //     dispatch({ type: ActionType.FETCH_POSTS, payload: response.data });
  //   };
  // }

  const addTodo = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    dispatch({ type: "ADD_TODO", text: todoValue })
    setTodoValue("");
  }

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setTodoValue(event.target.value);
  }

  return (
    <div className="App">
      <p>Clicked: {counter} times</p>
      <button onClick={() => dispatch({ type: 'INCREMENT' })}>
        +
      </button>
      <button onClick={() => dispatch({ type: 'DECREMENT' })}>
        -
      </button>

      <ul>
        {todos.map((todo, index) => <li key={index}>{todo}</li>)}
      </ul>

      <form onSubmit={addTodo}>
        <input type="text" value={todoValue} onChange={handleChange} />
        <input type="submit" />
      </form>

    </div>
  );
}

export default App;
