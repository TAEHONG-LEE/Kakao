import axios from "axios";
import { ActionType } from "../reducers/posts";




// export async function fetchPostss() {
//     // counter의 state 가져오기!!!
//     const response = await axios.get("https://jsonplaceholder.typicode.com/posts");
//     // dispatch 함수가져오기 !!!
//     dispatch({ type: ActionType.FETCH_POSTS, payload: response.data });
// };


export const fetchPosts: any = () => {
    console.log('1');
    return async function fetchPostsThunk(dispatch: any, getState: any) {
        console.log('2');
        if (getState().counter > 5) return;
        const response = await axios.get("https://jsonplaceholder.typicode.com/posts");
        dispatch({ type: ActionType.FETCH_POSTS, payload: response.data });
    };
}