export interface Tag {
    tag: string;
    id: string;
}