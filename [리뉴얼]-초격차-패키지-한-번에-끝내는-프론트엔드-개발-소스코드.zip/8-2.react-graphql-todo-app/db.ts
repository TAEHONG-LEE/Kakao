module.exports = {
    todos: [
        { id: 0, text: '밥먹기', checked: false },
    ]
}