export function SetColors() {
    return (
        <>
            <div className="text-normal bg-normal "></div>
            <div className="text-fire bg-fire "></div>
            <div className="text-water bg-water "></div>
            <div className="text-electric bg-electric "></div>
            <div className="text-grass bg-grass "></div>
            <div className="text-ice bg-ice "></div>
            <div className="text-fighting bg-fighting "></div>
            <div className="text-poison bg-poison "></div>
            <div className="text-ground bg-ground "></div>
            <div className="text-flying bg-flying "></div>
            <div className="text-psychic bg-psychic "></div>
            <div className="text-bug bg-bug "></div>
            <div className="text-rock bg-rock "></div>
            <div className="text-ghost bg-ghost "></div>
            <div className="text-dragon bg-dragon "></div>
            <div className="text-dark bg-dark "></div>
            <div className="text-steel bg-steel "></div>
            <div className="text-fairy bg-fairy"></div>
            <div className="text-none bg-none"></div>
        </>
    )
}
