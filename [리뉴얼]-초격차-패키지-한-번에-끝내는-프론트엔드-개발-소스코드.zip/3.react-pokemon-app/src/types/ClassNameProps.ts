export interface ClassNameProps {
    className: string;
}