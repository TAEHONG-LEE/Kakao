import React from 'react';
import logo from './logo.svg';
import './App.css';
import TodoStore from './TodoStore';
import TodoList from './TodoList';

function App() {
  const todoStore = new TodoStore();
  console.log(todoStore);

  return (
    <div className="App">
      <TodoList todoStore={todoStore} />
    </div>
  );
}

export default App;
