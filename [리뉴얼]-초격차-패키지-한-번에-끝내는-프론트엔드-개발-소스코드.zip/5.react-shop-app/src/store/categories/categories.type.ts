export enum CategoriesName {
    All = "",
    Electronics = "Electronics",
    Jewelry = "Jewelery",
    MensClothing = `Men's clothing`,
    WomensClothing = `Women's clothing`
}