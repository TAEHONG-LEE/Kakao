import { B } from './test';

console.log('hi');

export { }