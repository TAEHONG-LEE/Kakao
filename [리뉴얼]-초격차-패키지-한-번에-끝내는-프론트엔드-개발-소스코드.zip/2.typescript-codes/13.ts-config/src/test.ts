
export const B = "B";

export {}