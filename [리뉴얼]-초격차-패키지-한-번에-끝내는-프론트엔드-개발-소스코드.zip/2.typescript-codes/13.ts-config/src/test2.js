
export const A = "A";

// parseFloat(3.124);