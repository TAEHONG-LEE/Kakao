let username = "John1";

console.log(username);